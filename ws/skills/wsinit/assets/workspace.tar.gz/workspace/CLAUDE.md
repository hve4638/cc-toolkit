# <폴더명>

<프로젝트> 의 개발 기록·문서를 위한 워크스페이스(ws repo)다. 이 폴더가 곧 문서 repo 이고, 내부 프로젝트 repo (<이름들>) 는 git 추적에서 제외된다. ticket·계획·버그리포트·결정 기록은 프로젝트 repo 가 아닌 여기에 둔다.

폴더 구조 및 작성 규칙에 대해서는 'rule of workspace' 를 확인한다.

## merge 커밋 메시지 형식

wtree 로 부모 브랜치에 merge(land 포함)할 때, 커밋 메시지는 제목 한 줄 + 빈 줄 + `<reason>` 블록으로 쓴다. `<reason>` 에는 작업의 의도와 맥락(왜 그런 결정을 내렸는지, 검토했다 버린 대안)을 담는다.

예시:
```
fix: 제목 한 줄

<reason>
작업의 의도와 맥락(왜 그런 결정을 내렸는지)
</reason>
```

## wtree 사용법

- 병합: `wtree merge --squash -m "..."`
- 병합 및 워크트리 정리: `wtree land --squash -m "<커밋 메시지>"`
- main 따라잡기: `wtree sync` — 부모를 이 브랜치로 merge

금지 사항
- 금지: `git merge`/`git switch`/`git branch -d`/`git worktree` 직접 사용 금지
- 허용: 워크트리 내 일반 작업(edit·commit·diff·log)은 자유.

그 외
- 인자 없이 `wtree` 를 치면 지금 위치에서 가능한 동작만 나온다.
- wtree 자체에 대한 세부 정보: `wtree llms.txt`.
